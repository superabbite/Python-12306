# this is a small package for automation buy tickets on 12306
