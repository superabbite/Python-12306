__title__ = 'py12306'
__version__ = '0.9.4'
__author__ = 'versionzhang'
__author_email__ = 'versionzhang@gmail.com'
__url__ = 'https://github.com/versionzhang/python_12306'
__description__ = "python抢票工具"
