class ResponseError(Exception):
    pass


class ResponseCodeError(Exception):
    pass


class AutoCodeConfigError(Exception):
    pass
