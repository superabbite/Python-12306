# this folder save some global data.
