# logic to process auto login, check left ticket and submit orders.
