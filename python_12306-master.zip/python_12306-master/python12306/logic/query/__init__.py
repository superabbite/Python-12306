# check query
