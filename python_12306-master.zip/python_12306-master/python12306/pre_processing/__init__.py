# parsing some data.
# 1. 获取车站信息
# 2. 获取乘客信息
